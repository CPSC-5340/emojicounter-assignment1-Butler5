//
// Assignment1App.swift : Assignment1
//
// Copyright © 2023 Auburn University.
// All Rights Reserved.


import SwiftUI

@main
struct Assignment1App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
